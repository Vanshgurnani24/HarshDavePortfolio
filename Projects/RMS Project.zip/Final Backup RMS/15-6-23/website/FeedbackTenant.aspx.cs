﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class FeedbackTenant : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("TenantLogin.aspx");
        }
    }
    
    protected void BtnInsert_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cm = new SqlCommand("PropertyFeedbackInsert", con);
        cm.CommandType = CommandType.StoredProcedure;
        cm.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.Int64;
        cm.Parameters.Add("@RegistrationID", Request.QueryString["RegistrationID"]).DbType = DbType.Int64;
        cm.Parameters.Add("@Rating", RatingTextBox.Text).DbType = DbType.Double;
        cm.Parameters.Add("@Review", ReviewTextBox.Text).DbType = DbType.String;
        cm.Parameters.Add("@PropertyID", Request.QueryString["PropertyID"]).DbType = DbType.Int64;
        cm.ExecuteNonQuery();
        cm.Dispose();
        SqlCommand cmd = new SqlCommand("UserAvgRating", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@RegistrationID", Request.QueryString["RegistrationID"]).DbType = DbType.Int64;
        cmd.Parameters.Add("@Rating", RatingTextBox.Text).DbType = DbType.Double;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();

    }
}