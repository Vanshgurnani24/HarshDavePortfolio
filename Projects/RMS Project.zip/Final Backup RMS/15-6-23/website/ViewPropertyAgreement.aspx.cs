﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class ViewPropertyAgreement : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    Int64 AgrID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("TenantLogin.aspx");

        }
        
            //String s = ("select agreementID from AgreementPropertyDetails where IsApproved=1");
            //SqlCommand cmd = new SqlCommand(s, con);
            //con.Open();
            //string aid = cmd.ExecuteScalar().ToString();
            //AgrID = Convert.ToInt64(aid);
            //GridViewRow gvr = (GridViewRow)GvPropertyAgreement.FindControl("AgreementID=" + AgrID);

            //if (gvr != null)
            //{
            //    gvr.Visible = false;
            //}
       
    }
    protected void Pay_Click(object sender, EventArgs e)
    {
        
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvPropertyAgreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        btn.Visible = false;
        Response.Redirect("Payment.aspx?AgreementID=" + AgrID);
       
    }
    protected void See_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvPropertyAgreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        String pro = ("select PropertyID from AgreementPropertyDetails where AgreementID='" + AgrID + "'");
        SqlCommand cmd = new SqlCommand(pro, con);
        con.Open();
        string proID = cmd.ExecuteScalar().ToString();
        Int64 ProID = Convert.ToInt64(proID);
        con.Close();
        Response.Redirect("PropertyDetails.aspx?PropertyID=" + ProID);

    }
    protected void Cancel_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvPropertyAgreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        String del = ("Delete from AgreementPropertyDetails where AgreementID='" + AgrID + "'");
        SqlCommand cmd = new SqlCommand(del, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void GvPropertyAgreement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            String s = ("select agreementID from  AgreementPropertyDetails where IsApproved=1");
            SqlCommand cmd = new SqlCommand(s, con);
            con.Open();
            string aid = cmd.ExecuteScalar().ToString();
            con.Close();
            for (int i = 0; i < GvPropertyAgreement.Rows.Count; i++)
            {
                GridViewRow row = GvPropertyAgreement.Rows[i];

                //Check your condition here
                if (row.Cells[0].Text == aid)
                {
                    row.Visible = false; //Hide the row
                }
            }
        }
        catch { }



        //string s = "select agreementID from  AgreementPropertyDetails where IsApproved=1";
        //SqlCommand cmd = new SqlCommand(s, con);
       

        // Use a List<string> to store the Agreement IDs
        //List<int> aid = new List<int>();
        //using (SqlDataReader reader = cmd.ExecuteReader())
        //{
        //    while (reader.Read())
        //    {
        //        aid.Add(reader.GetInt32(0));
        //    }
        //}
        //con.Close();

        ////for (int i = 0; i < GvPropertyAgreement.Rows.Count; i++)
        ////{
        ////    GridViewRow row = GvPropertyAgreement.Rows[i];
        ////    Int32 a = Convert.ToInt32(row.Cells[3].Text);
        ////    // Check if the Agreement ID is in the List
        ////    if (aid.Contains(a)) 
        ////    {
        ////        row.Visible = false; // Hide the row
        ////    }
        ////}
        //for (int i = 0; i < GvPropertyAgreement.Rows.Count; i++)
        //{
        //    GridViewRow row = GvPropertyAgreement.Rows[i];
        //    int a;
        //    if (Int32.TryParse(row.Cells[3].Text, out a))
        //    {
        //        // Check if the Agreement ID is in the List
        //        if (aid.Contains(a))
        //        {
        //            Button btn = (Button)sender;
        //            btn.Enabled = false; // Hide the row
        //        }
        //    }
            
        //}

        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    // Get the value of the "PaymentStatus" column for the current row
        
        //    string qry = ("select IsApproved from AgreementPropertyDetails where  agreementID='" + e.Row.Cells[3] + "'");
        //    SqlCommand cmd = new SqlCommand(qry, con);
        //    string approved = cmd.ExecuteScalar().ToString();
        //    Boolean a = Convert.ToBoolean(approved);
        //    // Find the button control in the current row
        //    Button btn = e.Row.FindControl("Pay") as Button;

        //    // Disable the button if the payment status is "Paid"
        //    if (a == true)
        //    {
        //        btn.Visible = false;
        //    }
        //}
        //con.Close();
//        if (e.Row.RowType == DataControlRowType.DataRow)
//{
//    // Get the value of the "agreementID" column for the current row
//    int agreementID = Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "agreementID"));

//    string qry = "select IsApproved from AgreementPropertyDetails where agreementID=@agreementID";
//    SqlCommand cmd = new SqlCommand(qry, con);
//    cmd.Parameters.AddWithValue("@agreementID", agreementID);

//    con.Open();
//    string approved = cmd.ExecuteScalar()? .ToString();
//    con.Close();

//    bool isApproved = approved != null && approved.ToLower() == "true";
    
//    // Find the button control in the current row
//    Button btn = e.Row.FindControl("Pay") as Button;

//    // Disable the button if the agreement is approved
//    if (isApproved)
//    {
//        btn.Enabled = false;
//    }
//}


    }
}