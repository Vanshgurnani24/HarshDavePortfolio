﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class PropertyDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            //Response.Redirect("TenantLogin.aspx");
           
        }

    }
    protected void DlistPropertyDetails_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //SqlCommand cmd = new SqlCommand("CheckPropertyID", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        ////cmd.Parameters.Add("@emailID", Email.Text).DbType = DbType.String;
        ////cmd.Parameters.Add("@Password", Pass.Text).DbType = DbType.String;
        //SqlDataAdapter da = new SqlDataAdapter(cmd);
        //DataSet ds = new DataSet();
        //da.Fill(ds);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Session["UserType"] = "Admin";
        //    Session["PropertyID"] = ds.Tables[0].Rows[0]["PropertyID"].ToString();
        //    //Response.Redirect("http://localhost:1037/website/HomePage.aspx");
        //}
        //else
        //{

        //}
        //        if (Request.QueryString["PropertyID"] != null )
        //{

        // //SqlCommand com = new SqlCommand("ADD_Data", con);
        // con.Parameters.AddWithValue("@PropertyID", Request.QueryString["PropertyID"].ToString());

        // com.CommandType = CommandType.StoredProcedure;
        // try
        // {
        //    con.Open();
        //    com.ExecuteNonQuery();
        // }
        // catch (Exception)
        // {
        //    throw;
        // }
        // finally
        // {
        //    if (con.State == ConnectionState.Open)
        //        con.Close();
        // }
        //}


        //    }
    }
    protected void DlistPropertyDetails_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            con.Open();
            String str = ("select IsApproved from  AgreementPropertyDetails where TenantRegistrationID='" + Session["TenantRegistrationID"] + "' and PropertyID='" + Request.QueryString["PropertyID"] + "'");
            SqlCommand cd = new SqlCommand(str, con);
            string approve = cd.ExecuteScalar().ToString();
            Boolean approved = Convert.ToBoolean(approve);
            if (approved == true)
            {
                HyperLink hl = (HyperLink)e.Item.FindControl("Rate");
                hl.Visible = true;
            }
            con.Close();
        }
        catch { }
    }
    protected void LbtnClick_Click(object sender, EventArgs e)
    {
        Label l = (Label)FindControl("PriceLabel");
        SqlCommand cmd = new SqlCommand("RequestForProprtyDetail", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Description", "Buy Now").DbType = DbType.String;
        cmd.Parameters.Add("@OfferPrice", 5000).DbType = DbType.String;
        cmd.Parameters.Add("@RequestDate", DateTime.Now).DbType = DbType.String;
        cmd.Parameters.Add("@PropertyID", Request.QueryString["PropertyID"]).DbType = DbType.String;
        cmd.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
    }
}

