﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class RegisterUser_AddAmenities : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("../DefaultUserLogin.aspx");
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("PropertyAmenitiesInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PropertyID", DDLProperty.SelectedValue).DbType = DbType.Int64;
        cmd.Parameters.Add("@AminityID", DDLAmenity.SelectedValue).DbType = DbType.Int64;
        cmd.Parameters.Add("@RegistrationID", Session["RegistrationID"]).DbType = DbType.Int64;
        cmd.ExecuteNonQuery();
        con.Close();
    }
}