﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_PropertyGallery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("../DefaultUserLogin.aspx");
        }
    }
    protected void dsProperyGallery_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        //DropDownList PropertyGallery = (DropDownList)FvPropertyGallery.FindControl("DsPropertyIDGallery");
        //e.Command.Parameters["@PropertyGalleryID"].Value = PropertyGallery.SelectedValue;
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString();
        FileUpload fa1 = (FileUpload)FvPropertyGallery.FindControl("PropertyFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../PropertyPhoto/") + name + strguid + ext;
                String strname = "../PropertyPhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@ImagePath"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }



    }
    protected void FvPropertyGallery_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvPropertyGallery.DataBind();
            //CloseMessages();
            //lblSuccess.Text = "Record inserted successfully.";
            //success.Style.Add("display", "block");
        }
    }
    //private void CloseMessages()
    //{
      //  error.Style.Add("display", "none");
        //info.Style.Add("display", "none");
        //success.Style.Add("display", "none");
        //attention.Style.Add("display", "none");
    //}
    
    protected void FvPropertyGallery_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvPropertyGallery.DataBind();
            //CloseMessages();
            //lblSuccess.Text = "Record Updated successfully.";
            //success.Style.Add("display", "block");
        }
    }
    protected void FvPropertyGallery_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvPropertyGallery.DataBind();
           
        }
    }
    protected void GvPropertyGallery_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvPropertyGallery.DataBind();
        FvPropertyGallery.ChangeMode(FormViewMode.Edit);
    }
    protected void GvPropertyGallery_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvPropertyGallery.DataBind();
            //CloseMessages();
            //lblSuccess.Text = "Record deleted successfully.";
            //success.Style.Add("display", "block");
        }
    }
}