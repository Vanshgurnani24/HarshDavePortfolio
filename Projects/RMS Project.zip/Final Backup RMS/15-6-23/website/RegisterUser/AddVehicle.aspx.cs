﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_AddVehicle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("http://localhost:1037/website/DefaultUserLogin.aspx");
        }
        

    }
    protected void FvVehicle_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
       
            if (e.AffectedRows > 0)
            {
                GvVehicle.DataBind();
                CloseMessages();
                lblSuccess.Text = "Record inserted successfully.";
                success.Style.Add("display", "block");
            }
        
    }

    protected void FvVehicle_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvVehicle.DataBind();
        }
    }
    protected void FvVehicle_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvVehicle.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvVehicle_SelectedIndexChanged(object sender, EventArgs e)
    {

        FvVehicle.DataBind();
        FvVehicle.ChangeMode(FormViewMode.Edit);
    }
    protected void dsVehicle_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString() ;
        FileUpload fa1 = (FileUpload)FvVehicle.FindControl("PropertyVehicleUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../VehiclePhoto/") + name + strguid + ext;
                String strname = "../VehiclePhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@CoverPhoto"].Value = strname;
            }
        }
            else
            {
                e.Cancel= true;
            }
        
        DropDownList stateID = (DropDownList)FvVehicle.FindControl("DdListAllState");
        e.Command.Parameters["@StateID"].Value = stateID.SelectedValue;
        DropDownList CityID = (DropDownList)FvVehicle.FindControl("DdlCityID");
        e.Command.Parameters["@CityID"].Value = CityID.SelectedValue;
        DropDownList AreaID = (DropDownList)FvVehicle.FindControl("DdlistAreaID");
        e.Command.Parameters["@AreaID"].Value = AreaID.SelectedValue;
        DropDownList PincodeID = (DropDownList)FvVehicle.FindControl("DdlistPincodeID");
        e.Command.Parameters["@PincodeID"].Value = PincodeID.SelectedValue;
        DropDownList VehicleTypeID = (DropDownList)FvVehicle.FindControl("DdlVehicleType");
        e.Command.Parameters["@VehicleTypeID"].Value = VehicleTypeID.SelectedValue;
        DropDownList TransmissionTypeID = (DropDownList)FvVehicle.FindControl("DdlTransmissionType");
        e.Command.Parameters["@TransmissionTypeID"].Value = TransmissionTypeID.SelectedValue;
        DropDownList FuelID = (DropDownList)FvVehicle.FindControl("DdlFuelType");
        e.Command.Parameters["@FuelID"].Value = FuelID.SelectedValue;
        DropDownList CountryID = (DropDownList)FvVehicle.FindControl("DdListAllCountry");
        e.Command.Parameters["@CountryID"].Value = CountryID.SelectedValue;


    
    }
    protected void FvVehicle_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}