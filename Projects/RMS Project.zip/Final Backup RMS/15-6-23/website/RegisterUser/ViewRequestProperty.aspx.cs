﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class RegisterUser_ViewRequestProperty : System.Web.UI.Page

{
    Int64 ProID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnApproved_Click(object sender, EventArgs e)
    {
        //Button btn = (Button)sender;
        //GridViewRow gvr;
        //gvr = (GridViewRow)btn.Parent.NamingContainer;
        //ProID = Convert.ToInt64(GvViewRequestedProprty.DataKeys[gvr.RowIndex].Values[0].ToString());

        //con.Open();
        //SqlCommand cmd = new SqlCommand("PriceAccept", con);
        //cmd.CommandType = CommandType.StoredProcedure;
        //cmd.Parameters.Add("@PropertyID", ProID).DbType = DbType.Int64;
        //cmd.ExecuteNonQuery();
        //cmd.Dispose();
        //con.Close();


        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        ProID = Convert.ToInt64(GvViewRequestedProprty.DataKeys[gvr.RowIndex].Values[0].ToString());
        con.Open();
        SqlCommand cmd = new SqlCommand("SupplyPropertyID", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@RequestID", ProID).DbType = DbType.Int64;
        SqlParameter parm = new SqlParameter("@PropertyID", SqlDbType.Int);
        parm.Direction = ParameterDirection.ReturnValue;
        cmd.Parameters.Add(parm);
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        SqlCommand cm = new SqlCommand("RequestApproval", con);
        Int64 PropertyID = Convert.ToInt64(parm.Value);
        cm.CommandType = CommandType.StoredProcedure;
        cm.Parameters.Add("@RequestID", ProID).DbType = DbType.Int64;
        cm.ExecuteNonQuery();
        cm.Dispose();
        SqlCommand c = new SqlCommand("RejectRequest", con);
        c.CommandType = CommandType.StoredProcedure;
        c.Parameters.Add("@RequestID", ProID).DbType = DbType.Int64;
        c.Parameters.Add("@PropertyID", PropertyID).DbType = DbType.Int64;
        c.ExecuteNonQuery();
        c.Dispose();
        SqlCommand ret = new SqlCommand("Inbox", con);
        ret.CommandType = CommandType.StoredProcedure;
        //SqlParameter tr = new SqlParameter("@TenantRegistrationID", SqlDbType.Bit);
        //tr.Direction = ParameterDirection.ReturnValue;
        //ret.Parameters.Add(tr);
        //Int64 TenantRegistrationID = Convert.ToInt64(tr.Value);
        ret.Parameters.Add("@RequestID", ProID).DbType = DbType.Int64;
        SqlParameter par = new SqlParameter("@IsApproved", SqlDbType.Bit);
        par.Direction = ParameterDirection.ReturnValue;
        ret.Parameters.Add(par);
        Int64 IsApprove = Convert.ToInt64(par.Value);
        String query = "update RequestPropertyDetail set Status='Accepted' where IsApproved=1";
        SqlCommand ins = new SqlCommand(query, con);
        ins.ExecuteNonQuery();
        ins.Dispose();
        String query2 = "update RequestPropertyDetail set Status='Pending' where IsApproved=0";
        SqlCommand ins2 = new SqlCommand(query2, con);
        ins2.ExecuteNonQuery();
        ins2.Dispose();
        con.Close();
    }
}