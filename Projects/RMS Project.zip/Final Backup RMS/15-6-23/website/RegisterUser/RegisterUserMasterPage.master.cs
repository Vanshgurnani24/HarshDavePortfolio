﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class RegisterUser_RegisterUserMasterPage : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnProfile_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("EditProfile", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@RegistrationID", Session["RegistrationID"]).DbType = DbType.Int64;
        FileUpload fa3 = (FileUpload)FindControl("FileUpload1");
        if (fa3.HasFile)
        {
            string strfilename = fa3.FileName;
            string ext = System.IO.Path.GetExtension(fa3.PostedFile.FileName);
            string name = System.IO.Path.GetFileNameWithoutExtension(fa3.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                string strguid = Guid.NewGuid().ToString();
                string savefilename = Server.MapPath("../ProfilePhoto/") + name + strguid + ext;
                string strname = "../ProfilePhoto/" + name + strguid + ext;
                fa3.SaveAs(savefilename);

                cmd.Parameters.Add("@ProfilePhoto", strname).DbType = DbType.String;

            }
        }
        cmd.Parameters.Add("@Name", Name.Text).DbType = DbType.String;
        cmd.Parameters.Add("@Mobile", TextBox2.Text).DbType = DbType.String;
        cmd.Parameters.Add("@Email", TextBox3.Text).DbType = DbType.String;
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("../DefaultUserLogin.aspx");
    }
}
