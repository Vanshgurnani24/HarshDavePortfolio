﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class RegisterUser_FeedbackForUser : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("http://localhost:1037/website/DefaultUserLogin.aspx");
        }
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cm = new SqlCommand("FeedBackMasterInsert", con);
        cm.CommandType = CommandType.StoredProcedure;
        cm.Parameters.Add("@RegistrationID", Session["RegistrationID"]).DbType = DbType.Int64;
        cm.Parameters.Add("@TenantRegistrationID", DDLUser.SelectedValue).DbType = DbType.Int64;
        cm.Parameters.Add("@Rating", RatingTextBox.Text).DbType = DbType.Double;
        cm.Parameters.Add("@Review", ReviewTextBox.Text).DbType = DbType.String;
        cm.Parameters.Add("@PropertyID", DdlPropertyIDFeedback.SelectedValue).DbType = DbType.Int64;
        cm.ExecuteNonQuery();
        cm.Dispose();
        SqlCommand cmd = new SqlCommand("TenantAvgRating", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@TenantRegistrationID", DDLUser.SelectedValue).DbType = DbType.Int64;
        cmd.Parameters.Add("@Rating", RatingTextBox.Text).DbType = DbType.Double;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();

    }
}