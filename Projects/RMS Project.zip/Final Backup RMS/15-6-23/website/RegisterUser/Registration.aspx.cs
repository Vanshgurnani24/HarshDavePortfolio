﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void dsRegistration_Inserting1(object sender, SqlDataSourceCommandEventArgs e)
    {
        DropDownList stateID = (DropDownList)FvRegistration.FindControl("DdlStateID");
        e.Command.Parameters["@StateID"].Value = stateID.SelectedValue;
        DropDownList CityID = (DropDownList)FvRegistration.FindControl("DdlCityID");
        e.Command.Parameters["@CityID"].Value = CityID.SelectedValue;
        DropDownList AreaID = (DropDownList)FvRegistration.FindControl("DdlAreaID");
        e.Command.Parameters["@AreaID"].Value = AreaID.SelectedValue;
        DropDownList PincodeID = (DropDownList)FvRegistration.FindControl("DdlPincodeID");
        e.Command.Parameters["@PincodeID"].Value = PincodeID.SelectedValue;

        FileUpload fa1 = (FileUpload)FvRegistration.FindControl("AadhaarFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../AadhaarPhoto/") + name + strguid + ext;
                String strname = "../AadhaarPhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@AadhaarFrontPhoto"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }

        FileUpload fa2 = (FileUpload)FvRegistration.FindControl("AadhaarBackFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa2.FileName;
            String ext = System.IO.Path.GetExtension(fa2.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa2.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../AadhaarPhoto/") + name + strguid + ext;
                String strname = "../AadhaarPhoto/" + name + strguid + ext;
                fa2.SaveAs(savefilename);
                e.Command.Parameters["@AadhaarBackPhoto"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }
        FileUpload fa3 = (FileUpload)FvRegistration.FindControl("ProfilePhoto");
        if (fa1.HasFile)
        {
            String strfilename = fa3.FileName;
            String ext = System.IO.Path.GetExtension(fa3.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa3.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../ProfilePhoto/") + name + strguid + ext;
                String strname = "../ProfilePhoto/" + name + strguid + ext;
                fa3.SaveAs(savefilename);
                e.Command.Parameters["@ProfilePhoto"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }
    }
}