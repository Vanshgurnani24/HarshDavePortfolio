﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_agreementVehicle : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("../DefaultUserLogin.aspx");
        }
    }
    protected void GvAgreementVehicle_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void dsAgreementVehicle_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString();
        DropDownList TenantRegistrationID = (DropDownList)FVAgreementVehicle.FindControl("DdlALLTenantRegistration");
        e.Command.Parameters["@TenantRegistrationID"].Value = TenantRegistrationID.SelectedValue;
    }
}