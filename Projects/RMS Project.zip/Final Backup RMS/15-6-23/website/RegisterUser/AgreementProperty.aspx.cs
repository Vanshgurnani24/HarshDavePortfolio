﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class RegisterUser_AgreementProperty : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("../DefaultUserLogin.aspx");
        }
    }
    protected void FvAgreementProperty_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAgreementProperty.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void FvAgreementProperty_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAgreementProperty.DataBind();

        }
    }
    protected void FvAgreementProperty_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAgreementProperty.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvAgreementProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvAgreementProperty.DataBind();
        FvAgreementProperty.ChangeMode(FormViewMode.Edit);
    }
    protected void GvAgreementProperty_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAgreementProperty.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Deleted successfully.";
            success.Style.Add("display", "block");

        }
    }
    protected void dsAgreementProperty_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString();
        DropDownList PropertyID = (DropDownList)FvAgreementProperty.FindControl("DdlPropertyID");
        e.Command.Parameters["@PropertyID"].Value = PropertyID.SelectedValue;
        DropDownList TenantRegistrationID = (DropDownList)FvAgreementProperty.FindControl("DdlTenantRegistrationID");
        e.Command.Parameters["@TenantRegistrationID"].Value = TenantRegistrationID.SelectedValue;
       
    }
    protected void GVDSAgreementProperty_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
    //    con.Open();
    //    SqlCommand cm = new SqlCommand("AgreementPropertyDetailsInsert", con);
    //    cm.Parameters.Add("@RegistrationID", Session["RegistrationID"]).DbType = DbType.Int64;
    //    con.Close();
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}