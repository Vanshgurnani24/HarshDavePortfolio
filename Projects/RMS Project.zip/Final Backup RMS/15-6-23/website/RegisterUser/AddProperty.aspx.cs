﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_AddProperty : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("../DefaultUserLogin.aspx");
        }

    }
    protected void dsproperty_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString();
        FileUpload fa1 = (FileUpload)FvProperty.FindControl("PropertyFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../PropertyPhoto/") + name + strguid + ext;
                String strname = "../PropertyPhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@CoverPhoto"].Value = strname;
            }
        }
            else
            {
                e.Cancel= true;
            }
        DropDownList CountryID = (DropDownList)FvProperty.FindControl("DdlCountry");
        e.Command.Parameters["@CountryID"].Value = CountryID.SelectedValue;
        DropDownList StateID = (DropDownList)FvProperty.FindControl("DdlState");
        e.Command.Parameters["@StateID"].Value = StateID.SelectedValue;
        DropDownList CityID = (DropDownList)FvProperty.FindControl("DdlCity");
        e.Command.Parameters["@CityID"].Value = CityID.SelectedValue;
        DropDownList AreaID = (DropDownList)FvProperty.FindControl("DdlArea");
        e.Command.Parameters["@AreaID"].Value = AreaID.SelectedValue;
        DropDownList PincodeID = (DropDownList)FvProperty.FindControl("DdlPincode");
        e.Command.Parameters["@PincodeID"].Value = PincodeID.SelectedValue;
        DropDownList PropertytypeID = (DropDownList)FvProperty.FindControl("DdlPropertyType");
        e.Command.Parameters["@PropertytypeID"].Value = PropertytypeID.SelectedValue;
        DropDownList PropertyCategoryID = (DropDownList)FvProperty.FindControl("DdlPropertyCategory");
        e.Command.Parameters["@PropertyCategoryID"].Value = PropertyCategoryID.SelectedValue;
        //Calendar FromDate = (Calendar)FvProperty.FindControl("CalendarFromDate");
        //e.Command.Parameters["@FromDate"].Value = FromDate.SelectedDate;
        //Calendar ToDate = (Calendar)FvProperty.FindControl("CalendarToDate");
        //e.Command.Parameters["@ToDate"].Value = ToDate.SelectedDate;
        DropDownList PropertyAmenities = (DropDownList)FvProperty.FindControl("DDlPropertyAmenities");
        e.Command.Parameters["@AminityID"].Value = PropertyAmenities.SelectedValue;






        FileUpload fa2 = (FileUpload)FvProperty.FindControl("FileUpload1");
        if (fa2.HasFile)
        {
            String strfilename = fa2.FileName;
            String ext = System.IO.Path.GetExtension(fa2.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa2.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../PropertyPhoto/") + name + strguid + ext;
                String strname = "../PropertyPhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@PropertyPapers"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }
        }
    

    protected void FvProperty_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvProperty.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
        
    }
    protected void FvProperty_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvProperty.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
        
    }
    protected void FvProperty_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvProperty.DataBind();
        }
        
    }
   
    protected void GvProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvProperty.DataBind();
        FvProperty.ChangeMode(FormViewMode.Edit);
    }

    protected void FvProperty_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
    protected void DDlPropertyAmenities_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
    protected void GvProperty_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        GvProperty.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record deleted successfully.";
        success.Style.Add("display", "block");
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}
