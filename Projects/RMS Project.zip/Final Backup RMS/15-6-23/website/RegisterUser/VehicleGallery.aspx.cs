﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class RegisterUser_VehicleGallery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("http://localhost:1037/website/DefaultUserLogin.aspx");
        }
    }
    protected void GVDSVehicleGallery_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void dsVehicleGallery_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        e.Command.Parameters["@RegistrationID"].Value = Session["RegistrationID"].ToString();
        FileUpload fa1 = (FileUpload)FvVehicleGallery.FindControl("PropertyFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("../VehiclePhoto/") + name + strguid + ext;
                String strname = "../VehiclePhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@ImagePath"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }
    }
}