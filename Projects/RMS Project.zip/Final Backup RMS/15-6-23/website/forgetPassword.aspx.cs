﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class forgetPassword : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void BtnForget_Click(object sender, EventArgs e)
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select Password from RegistrationDetail where email='" + txtEmail.Text + "'", con);
        string enpass = cmd.ExecuteScalar().ToString();
        con.Close();
        //Byte[] decry = Convert.FromBase64String(enpass);
        //String pass = System.Text.Encoding.UTF8.GetString(decry);
        MailAddress to = new MailAddress(txtEmail.Text);
        //MailAddress to = new MailAddress("kishuvaghela616@gmail.com");
        MailAddress from = new MailAddress("krishvaghela616@gmail.com");

        MailMessage email = new MailMessage(from, to);
        email.Subject = "Your Password";
        email.Body = "Here is your password\n" + enpass + "\nThanks,\nThe RMS team.";

        SmtpClient smtp = new SmtpClient();
        smtp.Host = "smtp.outlook.com";
        smtp.Port = 587;
        smtp.Credentials = new NetworkCredential("krishvaghela616@gmail.com", "#nitinkumar7982@");
        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
        smtp.EnableSsl = true;


        /* Send method called below is what will send off our email 
         * unless an exception is thrown.
         */
        smtp.Send(email);
    }
}