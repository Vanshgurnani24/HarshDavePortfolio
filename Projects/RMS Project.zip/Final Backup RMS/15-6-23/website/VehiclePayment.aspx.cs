﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class VehiclePayment : System.Web.UI.Page
{

    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    Int64 AgrID;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void pay_Click(object sender, EventArgs e)
    {
        SqlCommand cm = new SqlCommand("VehicleAgreementApproved", con);
        cm.CommandType = CommandType.StoredProcedure;
        cm.Parameters.AddWithValue("@agreementVehicleID", Request.QueryString["agreementVehicleID"]).DbType = DbType.Int64;


        con.Open();
        cm.ExecuteNonQuery();
        con.Close();
    }
}