﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class DefaultUserLogin : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("CheckUserLogin", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@email", txtEmail.Text).DbType = DbType.String;
        cmd.Parameters.Add("@Password", txtPassword.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["UserType"] = "Admin";
            Session["RegistrationID"] = ds.Tables[0].Rows[0]["RegistrationID"].ToString();
            Response.Redirect("RegisterUser/Welcome.aspx");
        }
        else
        {

        }
    }
}