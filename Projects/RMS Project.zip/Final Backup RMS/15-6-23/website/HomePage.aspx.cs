﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class HomePage : System.Web.UI.Page
{
    Int64 pgid;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
  
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            //Response.Redirect("Default.aspx");
        }
        else
        {
            //con.Open();
            //SqlCommand cmd = new SqlCommand("SupplyTenantRegistrationID", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            //cmd.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.Int64;
            //SqlParameter par = new SqlParameter("@tid", SqlDbType.Int);
            //par.Direction = ParameterDirection.ReturnValue;
            //cmd.Parameters.Add(par);
            //cmd.ExecuteNonQuery();
            //Int64 tid = Convert.ToInt64(par.Value);
            //DateTime currentdate = DateTime.Now;
            //try
            //{
            //    SqlCommand expireagreement = new SqlCommand("GetExpiryDate", con);
            //    expireagreement.CommandType = CommandType.StoredProcedure;
            //    expireagreement.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.Int64;

            //    string date = expireagreement.ExecuteScalar().ToString();

            //    DateTime expdate = Convert.ToDateTime(date);
            //    if (currentdate >= expdate)
            //    {
            //        String del = ("Delete from AgreementPropertyDetails where TenantRegistrationID='" + tid + "' and IsApproved=1 ");
            //        SqlCommand delete = new SqlCommand(del, con);
            //        delete.ExecuteNonQuery();
            //    }
            //    con.Close();
            //}
            //catch { }
        }


        //if (Session["UserType"] != "Admin")
        //{
        //    //Response.Redirect("Default.aspx");
        //}
        //else
        //{
        //    con.Open();
        //    SqlCommand cmd = new SqlCommand("SupplyTenantRegistrationID", con);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    cmd.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.Int64;
        //    SqlParameter par = new SqlParameter("@tid", SqlDbType.Int);
        //    par.Direction = ParameterDirection.ReturnValue;
        //    cmd.Parameters.Add(par);
        //    cmd.ExecuteNonQuery();
        //    Int64 tid = Convert.ToInt64(par.Value);
        //    DateTime currentdate = DateTime.Now;
        //    try
        //    {
        //        SqlCommand expireagreement = new SqlCommand("GetVehicleExpiryDate", con);
        //        expireagreement.CommandType = CommandType.StoredProcedure;
        //        expireagreement.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.Int64;

        //        string date = expireagreement.ExecuteScalar().ToString();

        //        DateTime expdate = Convert.ToDateTime(date);
        //        if (currentdate >= expdate)
        //        {
        //            String del = ("Delete from AgreementVehicleDetails where TenantRegistrationID='" + tid + "' and IsApproved=1 ");
        //            SqlCommand delete = new SqlCommand(del, con);
        //            delete.ExecuteNonQuery();
        //        }
               
        //    }
        //    catch {   }
        //    con.Close();
        //}
    }
    protected void LBtnResidential_Click(object sender, EventArgs e)
    {
        con.Open();


        String qry = ("select PropertyCategoryID from PropertyCategoryMaster where PropertyCategory='residential'");
        SqlCommand cmd = new SqlCommand(qry, con);
      
            string id = cmd.ExecuteScalar().ToString();


           
            pgid = Convert.ToInt64(id);
            if (pgid != null)
            {
                Response.Redirect("PropertyList.aspx?PropertyCategoryID=" + pgid);
            }
            else
            {
                Response.Redirect("NoDataFound.aspx");
            }
        
            
         
        con.Close();
    }

    protected void LbtnCom_Click(object sender, EventArgs e)
    {
        con.Open();


        String qry = ("select PropertyCategoryID from PropertyCategoryMaster where PropertyCategory='Commerical'");
        SqlCommand cmd = new SqlCommand(qry, con);

        string id = cmd.ExecuteScalar().ToString();



        pgid = Convert.ToInt64(id);
        if (pgid != null)
        {
            Response.Redirect("PropertyList.aspx?PropertyCategoryID=" + pgid);
        }
        else
        {
            Response.Redirect("NoDataFound.aspx");
        }



        con.Close();
    }
    protected void LbtnApartment_Click(object sender, EventArgs e)
    {
        con.Open();


        String qry = ("select PropertyCategoryID from PropertyCategoryMaster where PropertyCategory='apartment'");
        SqlCommand cmd = new SqlCommand(qry, con);

        string id = cmd.ExecuteScalar().ToString();



        pgid = Convert.ToInt64(id);
        if (pgid != null)
        {
            Response.Redirect("PropertyList.aspx?PropertyCategoryID=" + pgid);
        }
        else
        {
            Response.Redirect("NoDataFound.aspx");
        }
    }
    protected void LbtnIndustrial_Click(object sender, EventArgs e)
    {
       



       
            Response.Redirect("NoDataFound.aspx");
        
    }
    protected void LbtnLand_Click(object sender, EventArgs e)
    {

        Response.Redirect("NoDataFound.aspx");
    }
    protected void lbtnBuilding_Click(object sender, EventArgs e)
    {

        Response.Redirect("NoDataFound.aspx");
    }
    protected void ImageBtnSedan_Click(object sender, ImageClickEventArgs e)
    {
        con.Open();


        String qry = ("select VehicleTypeID from VehicleTypeMaster where VehicleType='Sedan'");
        SqlCommand cmd = new SqlCommand(qry, con);

        string id = cmd.ExecuteScalar().ToString();



        pgid = Convert.ToInt64(id);
        if (pgid != null)
        {
            Response.Redirect("VehicleTypeList.aspx?VehicleTypeID=" + pgid);
        }
        else
        {
            Response.Redirect("NoDataFound.aspx");
        }



        con.Close();
    }
}   