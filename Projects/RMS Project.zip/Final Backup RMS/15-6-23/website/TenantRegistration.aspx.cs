﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class TenantRegistration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void dsTenantRegistration_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DropDownList stateID = (DropDownList)FvTenantRegistration.FindControl("DdlStateID");
        e.Command.Parameters["@StateID"].Value = stateID.SelectedValue;
        DropDownList CityID = (DropDownList)FvTenantRegistration.FindControl("DdlCityID");
        e.Command.Parameters["@CityID"].Value = CityID.SelectedValue;
        DropDownList AreaID = (DropDownList)FvTenantRegistration.FindControl("DdlAreaID");
        e.Command.Parameters["@AreaID"].Value = AreaID.SelectedValue;
        DropDownList PincodeID = (DropDownList)FvTenantRegistration.FindControl("DdlPincodeID");
        e.Command.Parameters["@PincodeID"].Value = PincodeID.SelectedValue;
        FileUpload fa1 = (FileUpload)FvTenantRegistration.FindControl("AadhaarFileUpload");
        if (fa1.HasFile)
        {
            String strfilename = fa1.FileName;
            String ext = System.IO.Path.GetExtension(fa1.PostedFile.FileName);
            String name = System.IO.Path.GetFileNameWithoutExtension(fa1.PostedFile.FileName);
            if (ext == ".JPG" || ext == ".jpg" || ext == ".PNG" || ext == ".png" || ext == ".JPEG" || ext == ".jpeg")
            {
                String strguid = Guid.NewGuid().ToString();
                String savefilename = Server.MapPath("AadhaarPhoto/") + name + strguid + ext;
                String strname = "AadhaarPhoto/" + name + strguid + ext;
                fa1.SaveAs(savefilename);
                e.Command.Parameters["@AadhaarPhoto"].Value = strname;
            }
        }
        else
        {
            e.Cancel = true;
        }
    }
}