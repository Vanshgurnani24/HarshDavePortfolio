﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class ViewVehicleAgreements : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    Int64 AgrID;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("TenantLogin.aspx");
        }
    }
    protected void Pay_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvVehicleagreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        //Response.Redirect("Payment.aspx?AgreementID={0}&agreementVehicleID={1}=" + AgrID);
        Response.Redirect("VehiclePayment.aspx?agreementVehicleID=" + AgrID);
    }
    protected void See_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvVehicleagreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        String pro = ("select VehicleID from AgreementVehicleDetails where agreementVehicleID='" + AgrID + "'");
        SqlCommand cmd = new SqlCommand(pro, con);
        con.Open();
        string proID = cmd.ExecuteScalar().ToString();
        Int64 ProID = Convert.ToInt64(proID);
        con.Close();
        Response.Redirect("VehicleDetails.aspx?VehicleID=" + ProID);

    }
    protected void Cancel_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        AgrID = Convert.ToInt64(GvVehicleagreement.DataKeys[gvr.RowIndex].Values[0].ToString());
        String del = ("Delete from AgreementVehicleDetails where AgreementVehicleID='" + AgrID + "'");
        SqlCommand cmd = new SqlCommand(del, con);
        con.Open();
        cmd.ExecuteNonQuery();
        con.Close();
    }
    protected void GvVehicleagreement_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            String s = ("select agreementVehicleID from  AgreementVehicleDetails where IsApproved=1");
            SqlCommand cmd = new SqlCommand(s, con);
            con.Open();
            string aid = cmd.ExecuteScalar().ToString();
            con.Close();
            for (int i = 0; i < GvVehicleagreement.Rows.Count; i++)
            {
                GridViewRow row = GvVehicleagreement.Rows[i];

                //Check your condition here
                if (row.Cells[0].Text == aid)
                {
                    row.Visible = false; //Hide the row
                }
            }
        }
        catch { }
    }
}