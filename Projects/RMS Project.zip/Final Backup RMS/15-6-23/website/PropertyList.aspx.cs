﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PropertyList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (DLPropertyList != null)
        {
            if (DLPropertyList.Items.Count > 0)
            {
                //Code to be executed
            }
            else
            {
                Response.Redirect("NoDataFound.aspx");
            }
        }
        else
        {
            Response.Redirect("NoDataFound.aspx");
        }
    }
}