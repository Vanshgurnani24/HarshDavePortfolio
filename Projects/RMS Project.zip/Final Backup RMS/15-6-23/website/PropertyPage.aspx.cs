﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;



public partial class PropertyPage : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());

    protected void Page_Load(object sender, EventArgs e)
    {


    }
    protected void DdlProperty_SelectedIndexChanged(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("PropertyDetailsGet", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Session["UserType"] = "Admin";
            Session["Property"] = ds.Tables[0].Rows[0]["PropertyID"].ToString();
            Response.Redirect("http://localhost:1037/website/SeeDetailsProperty.aspx");
        }
        else
        {

        }

    }
}