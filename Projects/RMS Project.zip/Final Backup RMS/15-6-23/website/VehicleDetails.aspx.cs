﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class VehicleDetails : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            //Response.Redirect("TenantLogin.aspx");

        }
    }
    protected void DlistVehicle_ItemDataBound(object sender, DataListItemEventArgs e)
    {
        try
        {
            con.Open();
            String str = ("select IsApproved from  AgreementVehicleDetails where TenantRegistrationID='" + Session["TenantRegistrationID"] + "' and VehicleID='" + Request.QueryString["VehicleID"] + "'");
            SqlCommand cd = new SqlCommand(str, con);
            string approve = cd.ExecuteScalar().ToString();
            Boolean approved = Convert.ToBoolean(approve);
            if (approved == true)
            {
                HyperLink hl = (HyperLink)e.Item.FindControl("HlFeedback");
                hl.Visible = true;
            }
            con.Close();
        }
        catch { }
    }
    protected void LbtnClick_Click(object sender, EventArgs e)
    {
        Label l = (Label)FindControl("PriceLabel");
        SqlCommand cmd = new SqlCommand("RequestVehicleInsert", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@Description", "Buy Now").DbType = DbType.String;
        cmd.Parameters.Add("@OfferPrice", 5000).DbType = DbType.String;
        cmd.Parameters.Add("@RequestDate", DateTime.Now).DbType = DbType.String;
        cmd.Parameters.Add("@VehicleID", Request.QueryString["VehicleID"]).DbType = DbType.String;
        cmd.Parameters.Add("@TenantRegistrationID", Session["TenantRegistrationID"]).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
    }
}