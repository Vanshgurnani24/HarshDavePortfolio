﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;


public partial class ClientMasterPage : System.Web.UI.MasterPage
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void login_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("CheckTenantLogin", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@emailID", Email.Text).DbType = DbType.String;
        cmd.Parameters.Add("@Password", Pass.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["UserType"] = "Admin";
            Session["TenantRegistrationID"] = ds.Tables[0].Rows[0]["TenantRegistrationID"].ToString();
            Response.Redirect("HomePage.aspx");
        }
        else
        {

        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Session.Clear();
        Session.Abandon();
        Response.Redirect("HomePage.aspx");
    }
}
