﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_PropertyApproval : System.Web.UI.Page
{
    Int64 ProID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GvPropertyApproval_SelectedIndexChanged(object sender, EventArgs e)
    {
       
    }
  
    protected void BtnApproved_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        ProID = Convert.ToInt64(GvPropertyApproval.DataKeys[gvr.RowIndex].Values[0].ToString());

        con.Open();
        SqlCommand cmd = new SqlCommand("PropertyApproval", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@PropertyID", ProID).DbType = DbType.Int64;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
    }
}