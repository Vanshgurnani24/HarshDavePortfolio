﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_CityMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void FvCityMaster_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvCityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void FvCityMaster_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvCityMaster.DataBind();
        }
    }
    
    protected void DsSateID_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void DsCityMaster_Inserting(object sender, SqlDataSourceCommandEventArgs e)
    {
        DropDownList stateID = (DropDownList)FvCityMaster.FindControl("DdListAllState");
        e.Command.Parameters["@StateID"].Value = stateID.SelectedValue;
    }
    protected void DsCityMaster_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void DsCityMasetrList_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void GvCityMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvCityMaster.DataBind();
        FvCityMaster.ChangeMode(FormViewMode.Edit);
    }
    protected void FvCityMaster_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvCityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvCityMaster_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvCityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}