﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_VehicleType : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void FvVehicleType_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        FvVehicleType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record inserted successfully.";
        success.Style.Add("display", "block");
    }
    protected void FvVehicleType_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        FvVehicleType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record Updated successfully.";
        success.Style.Add("display", "block");
    }
    protected void FvVehicleType_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        FvVehicleType.DataBind();
    }
    protected void GvVehicleType_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvVehicleType.DataBind();
        FvVehicleType.ChangeMode(FormViewMode.Edit);
    }
    protected void GvVehicleType_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        GvVehicleType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record deleted successfully.";
        success.Style.Add("display", "block");
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}