﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_Default : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        SqlCommand cmd = new SqlCommand("CheckedAdminLogin", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@UserName", txtUserName.Text).DbType = DbType.String;
        cmd.Parameters.Add("@Password", txtPassword.Text).DbType = DbType.String;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            Session["UserType"] = "Admin";
            Response.Redirect("Home1.aspx");
        }
        else
        { 
        
        }
    }
}