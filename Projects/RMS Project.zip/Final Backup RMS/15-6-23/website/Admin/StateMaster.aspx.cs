﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_StateMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("Default.aspx");
        }
    }
    protected void FVStateMaster_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GVStateMaster.DataBind();
        }
    }
    protected void FVStateMaster_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GVStateMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GVStateMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        FVStateMaster.DataBind();
        FVStateMaster.ChangeMode(FormViewMode.Edit);
    }
    protected void FVStateMaster_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
    protected void FVDS_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void FVStateMaster_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GVStateMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GVStateMaster_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GVStateMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}