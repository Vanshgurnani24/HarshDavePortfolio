﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_AminityMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("Default.aspx");
        }

    }
    protected void FvAminityMaster_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvAminityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void FvAminityMaster_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAminityMaster.DataBind();
        }
    }
    protected void FvAminityMaster_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAminityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvAminityMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvAminityMaster.DataBind();
        FvAminityMaster.ChangeMode(FormViewMode.Edit);
    }
    protected void FvAminityMaster_PageIndexChanging(object sender, FormViewPageEventArgs e)
    {

    }
    protected void DsAminityMasterList_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void GvAminityMaster_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvAminityMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}