﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_TransmissionType : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void FvTransmissionType_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        GvTransmissionType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record inserted successfully.";
        success.Style.Add("display", "block");
    }
    protected void FvTransmissionType_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        GvTransmissionType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record deleted successfully.";
        success.Style.Add("display", "block");
    }
    protected void FvTransmissionType_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        GvTransmissionType.DataBind();
        CloseMessages();
        lblSuccess.Text = "Record Updated successfully.";
        success.Style.Add("display", "block");
    }

    protected void GvTransmissionType_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvTransmissionType.DataBind();
        FvTransmissionType.ChangeMode(FormViewMode.Edit);
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
    protected void GvTransmissionType_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvTransmissionType.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
}