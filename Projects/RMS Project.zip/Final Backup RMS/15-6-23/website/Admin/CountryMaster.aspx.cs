﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_CountryMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("Default.aspx");
        }

    }
    protected void FvCountryMaster_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvCountryMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }

    }
    protected void FvCountryMaster_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvCountryMaster.DataBind();
        }
    }
    protected void GvCountryMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvCountryMaster.DataBind();
        FvCountryMaster.ChangeMode(FormViewMode.Edit);

    }
    protected void FvCountryMaster_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvCountryMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }

    protected void GvCountryMaster_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvCountryMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
}