﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_VehicleApproval : System.Web.UI.Page
{
    Int64 VehID;
    SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString.ToString());
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void GvVehicleApproval_SelectedIndexChanged(object sender, EventArgs e)
    {
    //        intID = Convert. ToInt64(gvcatagoryview.selectedDatakey["CatagoryID"].Tostring());
    //Sqlcommand md = new Sqlcommand("CatagorybyID", con);
    //cmd.CommandType = CommandType. StoredProcedure;
    //cmd.Parameters.Addwithvalue("@CatagoryID",intID).DbType=DbType.Int32;
    //SqlDataAdapter da = new SqlDataAdapter (cmd) ;
    //Dataset ds = new Dataset);
    //da.Fill(ds);
    //if (ds.Tables [0]. Rows. Count > 0)
    //{
    //txtcatagoryname.Tooltip = ds. Tables[0]-Rows[0]["CatagoryID"] . Tostring();
    //txtcatagoryname. Text = ds. Tables [0]. Rows [0][ "CatagoryName"].Tostring();
    //}
    //btnsubmit.Text = "Update"

    }
   
    protected void BtnApproved_Click(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        GridViewRow gvr;
        gvr = (GridViewRow)btn.Parent.NamingContainer;
        VehID = Convert.ToInt64(GvVehicleApproval.DataKeys[gvr.RowIndex].Values[0].ToString());

        con.Open();
        SqlCommand cmd = new SqlCommand("VehicleApproval", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.Add("@VehicleID", VehID).DbType = DbType.Int64;
        cmd.ExecuteNonQuery();
        cmd.Dispose();
        con.Close();
    }
}