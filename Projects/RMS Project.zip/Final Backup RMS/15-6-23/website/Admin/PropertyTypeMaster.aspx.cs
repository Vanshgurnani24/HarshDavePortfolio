﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_PropertyTypeMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("Default.aspx");
        }
    }
    protected void FvPropertyTypeMaster_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyTypeMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void FvPropertyTypeMaster_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {
        if (e.AffectedRows > 0)
        {
            GvPropertyTypeMaster.DataBind();
        }
    }
    protected void GvPropertyTypeMaster_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvPropertyTypeMaster.DataBind();
        FvPropertyTypeMaster.ChangeMode(FormViewMode.Edit);
    }
    protected void FvPropertyTypeMaster_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyTypeMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvPropertyTypeMaster_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyTypeMaster.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}