﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_PropertyCategoryMaster : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["UserType"] != "Admin")
        {
            Response.Redirect("Default.aspx");
        }

    }
    protected void FvPropertyCategory_ItemInserted(object sender, FormViewInsertedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyCategory.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record inserted successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void GvPropertyCategory_SelectedIndexChanged(object sender, EventArgs e)
    {
        FvPropertyCategory.DataBind();
        FvPropertyCategory.ChangeMode(FormViewMode.Edit);
    }
    protected void FvPropertyCategory_ItemUpdated(object sender, FormViewUpdatedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyCategory.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record Updated successfully.";
            success.Style.Add("display", "block");
        }
    }
    protected void FvPropertyCategory_ItemDeleted(object sender, FormViewDeletedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyCategory.DataBind();
        }
    }
    protected void GvPropertyCategory_RowDeleted(object sender, GridViewDeletedEventArgs e)
    {

        if (e.AffectedRows > 0)
        {
            GvPropertyCategory.DataBind();
            CloseMessages();
            lblSuccess.Text = "Record deleted successfully.";
            success.Style.Add("display", "block");
        }
    }
    private void CloseMessages()
    {
        error.Style.Add("display", "none");
        info.Style.Add("display", "none");
        success.Style.Add("display", "none");
        attention.Style.Add("display", "none");
    }
}